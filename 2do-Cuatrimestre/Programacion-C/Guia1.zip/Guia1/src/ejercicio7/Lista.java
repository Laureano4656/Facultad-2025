package ejercicio7;

public class Lista {	
	private NodoLista primero;
	
	public Lista() {
		this.primero  = null;	
	}
	public NodoLista getPrimero() {
		return this.primero;
	}
	public void setPrimero(NodoLista x) {
		this.primero = x;
	}
}
