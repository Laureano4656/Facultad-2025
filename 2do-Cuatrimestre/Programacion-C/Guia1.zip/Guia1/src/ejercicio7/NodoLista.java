package ejercicio7;

public class NodoLista {
	private NodoLista sig;
	private int dato;
	
	public NodoLista(int x) {
		this.dato = x;
		this.sig = null;
	}
	public NodoLista avanza() {
		return this.sig;
	}
	public void setSig(NodoLista x) {
		this.sig = x;
	}
	public int getDato() {
		return this.dato;
	}
}
