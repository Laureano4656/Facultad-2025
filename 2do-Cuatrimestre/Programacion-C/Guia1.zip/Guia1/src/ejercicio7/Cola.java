package ejercicio7;

public class Cola {
	private int vec[];
	private int primero;
	
	public Cola() {

	}
	
}
