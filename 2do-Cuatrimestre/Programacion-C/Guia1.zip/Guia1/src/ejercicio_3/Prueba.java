package ejercicio_3;

public class Prueba {
	
	public static void main(String[] args) {
		Empleado emp1 = new Empleado();
		Empleado emp2 = new Empleado();
		Empleado emp3 = new Empleado();
		Empleado emp4 = new Empleado();
		Empleado emp5 = new Empleado();
		Empleado emp6 = new Empleado();
		
		Categoria cat1 = new Categoria("Principiante",80);
		Categoria cat2 = new Categoria("Operario",100);
		Categoria cat3 = new Categoria("Experto",130);
		
		emp1.setNombre("Juan Perez");
		emp1.setCat(cat1);
		emp1.setHstrabajadas(100);
		emp1.setAntiguedad(4);
		
		emp2.setNombre("Roberto Gonzales");
		emp2.setCat(cat1);
		emp2.setHstrabajadas(120);
		emp2.setAntiguedad(14);
		
		emp3.setNombre("Sandra Lopez");
		emp3.setCat(cat1);
		emp3.setHstrabajadas(120);
		emp3.setAntiguedad(14);
		
		emp4.setNombre("German Gutierrez");
		emp4.setCat(cat2);
		emp4.setHstrabajadas(110);
		emp4.setAntiguedad(16);
		
		emp5.setNombre("Vicente Hernandez");
		emp5.setCat(cat2);
		emp5.setHstrabajadas(100);
		emp5.setAntiguedad(9);
		
		emp6.setNombre("Carolina Gomez");
		emp6.setCat(cat3);
		emp6.setHstrabajadas(115);
		emp6.setAntiguedad(20);
		
		
	}

}
