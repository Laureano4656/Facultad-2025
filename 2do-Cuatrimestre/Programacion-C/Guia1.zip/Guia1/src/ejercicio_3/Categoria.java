package ejercicio_3;

public class Categoria {
	private String nombrecategoria;
	private double sueldoporhora;
	
	public Categoria(String nombrecategoria, double sueldoporhora) {
		// TODO Auto-generated constructor stub
		this.nombrecategoria = nombrecategoria;
		this.sueldoporhora = sueldoporhora;
	}

	public String getNombrecategoria() {
		return nombrecategoria;
	}

	public void setNombrecategoria(String nombrecategoria) {
		this.nombrecategoria = nombrecategoria;
	}

	public double getSueldoporhora() {
		return sueldoporhora;
	}

	public void setSueldoporhora(double sueldoporhora) {
		this.sueldoporhora = sueldoporhora;
	}

}
