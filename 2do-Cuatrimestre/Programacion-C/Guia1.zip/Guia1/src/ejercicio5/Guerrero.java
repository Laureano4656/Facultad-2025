package ejercicio5;

public class Guerrero {
	private String nombre;
	private double vitalidad;
	private double armadura;
	private double x;
	private double y;
	
	public Guerrero() {
		// TODO Auto-generated constructor stub
	}
	void mover(double inc_x, double inc_y) {
		this.x +=inc_x;
		this.y +=inc_y;
	}
	void recibeDano(double cantidad) {
		if (this.armadura - cantidad < 0) {
			this.vitalidad = cantidad - this.armadura;
			this.armadura = 0;
		}else {
			this.armadura -=cantidad;
		}
	}
}
