package ejercicio6;

public class Socio {
	private int edad;
	private String nombre;
	private boolean torneos; 
	public Socio(int edad, String nombre) {
		this.edad = edad;
		this.nombre = nombre;
		this.torneos = false;
	}
	public Socio(int edad, String nombre,boolean torneos) {
		this.edad = edad;
		this.nombre = nombre;
		this.torneos = torneos;
	}
	final static double valorCuota = 500;
	public double calcularCuota() {		
		if (this.edad > 65) 
		 return 0.5 * valorCuota;
		else
		 if (this.edad < 18 && this.torneos)
		  return 0.75 * valorCuota;
		 else
		  return valorCuota;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isTorneos() {
		return torneos;
	}
	public void setTorneos(boolean torneos) {
		this.torneos = torneos;
	}
	public static double getValorcuota() {
		return valorCuota;
	}
}
