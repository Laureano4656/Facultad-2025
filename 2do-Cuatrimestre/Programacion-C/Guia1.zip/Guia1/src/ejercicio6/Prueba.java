package ejercicio6;

public class Prueba {
	public static void main(String args[]) {
		Socio socio1 = new Socio(70,"Pedro");
		Socio socio2 = new Socio(10,"Juancito",true);
		Socio socio3 = new Socio(18,"Hijo de pedro");
		
		System.out.println("NOMBRE: "+socio1.getNombre()+"\nEDAD: " + socio1.getEdad()+"\nCUOTA: "+socio1.calcularCuota());
		System.out.println("NOMBRE: "+socio2.getNombre()+"\nEDAD: " + socio2.getEdad()+"\nCUOTA: "+socio2.calcularCuota());
		System.out.println("NOMBRE: "+socio3.getNombre()+"\nEDAD: " + socio3.getEdad()+"\nCUOTA: "+socio3.calcularCuota());
	}
}
